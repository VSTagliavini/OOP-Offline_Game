public class Item extends Entidade {
    
}