public class Inimigo extends Entidade {
    
}