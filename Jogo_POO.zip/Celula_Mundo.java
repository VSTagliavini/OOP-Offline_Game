import java.awt.Image;
import java.io.IOException;
import java.awt.Graphics;

abstract class Celula_Mundo extends Atomo {
}